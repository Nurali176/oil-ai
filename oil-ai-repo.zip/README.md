
# oil-ai

AI Oil Exploration Platform

## Deploy to Vercel

[![Deploy to Vercel](https://vercel.com/button)](https://vercel.com/new/git/external?repository-url=https://github.com/yourusername/oil-ai&project-name=oil-ai&repository-name=oil-ai)

## Run locally

### Docker
```bash
docker-compose up --build
```
### Without Docker
Frontend: `cd frontend && npm install && npm run dev`  
Backend: `cd backend && npm install && npm run dev`
